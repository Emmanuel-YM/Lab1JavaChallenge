public class StringLength { // Name of Class
    public static void main(String[] args){
        // Declaring the String Object
        String str= "input"; 
        
        int strLength = str.length(); //length() method of String returns the length of a String.
        System.out.println("Length of a String is : " + strLength); //Printing the output.
    }
    
}

